package com.peak.salut.Callbacks;

public interface SalutCallback {
    void call();
}
