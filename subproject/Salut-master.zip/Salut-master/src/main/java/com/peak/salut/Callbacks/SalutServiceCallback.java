package com.peak.salut.Callbacks;

import com.peak.salut.SalutDevice;

public interface SalutServiceCallback {
    void call(SalutDevice foundService);
}
