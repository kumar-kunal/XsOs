package com.peak.salut.Callbacks;


public interface SalutDataCallback {

    void onDataReceived(Object data);
}
